Ducky-Flasher
Easily flash your USB Rubber ducky from Hak5!

#Firmwares included:
	1. duck.hex v2 (Duck(Original))
	2. usb.hex v2 (FAT Duck)
	3. m_duck.hex v2 (Detour Duck(formerly Naked Duck))
	4. c_duck.hex v2 (Twin Duck)
	5. Twin Duck Versions (Original, Special 1, Special 2)
#To read more about the firmware go here
https://code.google.com/p/ducky-decode/wiki/Which_Firmware

#To install ducky-flasher run sudo python setup.py
You must have dfu-programmer installed (sudo apt-get install dfu-programmer)

#To start ducky-flasher type ducky-flasher in your terminal emulator

#Uninstalling

To uninstall ducky-flasher run sudo python uninstall.py
